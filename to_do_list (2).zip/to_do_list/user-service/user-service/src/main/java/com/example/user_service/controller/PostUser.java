package com.example.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class PostUser {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping
    public ResponseEntity<Map<String, Object>> createUser(@RequestBody CreateUserRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Username is required");
                return ResponseEntity.badRequest().body(response);
            }
            
            if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Password is required");
                return ResponseEntity.badRequest().body(response);
            }

            String checkSql = "SELECT COUNT(*) FROM r_user WHERE c_username = ?";
            Integer count = jdbcTemplate.queryForObject(checkSql, Integer.class, request.getUsername());
            
            if (count != null && count > 0) {
                response.put("success", false);
                response.put("message", "User already exists");
                return ResponseEntity.badRequest().body(response);
            }

            String insertSql = "INSERT INTO r_user (c_username, c_password, c_created_date) VALUES (?, ?, NOW())";
            int rowsAffected = jdbcTemplate.update(insertSql, request.getUsername(), request.getPassword());
            
            if (rowsAffected > 0) {
                String selectSql = "SELECT c_userid AS userId, c_username AS username, c_created_date AS createdDate " +
                                  "FROM r_user WHERE c_username = ?";
                Map<String, Object> newUser = jdbcTemplate.queryForMap(selectSql, request.getUsername());
                
                response.put("success", true);
                response.put("message", "User created successfully");
                response.put("user", newUser);
                return ResponseEntity.status(201).body(response);
            } else {
                response.put("success", false);
                response.put("message", "Error creating user");
                return ResponseEntity.status(500).body(response);
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error creating user: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    public static class CreateUserRequest {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}