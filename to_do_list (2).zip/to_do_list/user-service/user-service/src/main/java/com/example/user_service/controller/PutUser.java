package com.example.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class PutUser {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PutMapping("/{userId}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable Long userId, @RequestBody UpdateUserRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Username is required");
                return ResponseEntity.badRequest().body(response);
            }
            
            if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Password is required");
                return ResponseEntity.badRequest().body(response);
            }

            String checkUserSql = "SELECT COUNT(*) FROM r_user WHERE c_userid = ?";
            Integer userExists = jdbcTemplate.queryForObject(checkUserSql, Integer.class, userId);
            
            if (userExists == null || userExists == 0) {
                response.put("success", false);
                response.put("message", "User not found");
                return ResponseEntity.status(404).body(response);
            }

            String checkUsernameSql = "SELECT COUNT(*) FROM r_user WHERE c_username = ? AND c_userid != ?";
            Integer usernameExists = jdbcTemplate.queryForObject(checkUsernameSql, Integer.class, request.getUsername(), userId);
            
            if (usernameExists != null && usernameExists > 0) {
                response.put("success", false);
                response.put("message", "Username already exists");
                return ResponseEntity.badRequest().body(response);
            }
            String updateSql = "UPDATE r_user SET c_username = ?, c_password = ? WHERE c_userid = ?";
            int rowsAffected = jdbcTemplate.update(updateSql, request.getUsername(), request.getPassword(), userId);
            
            if (rowsAffected > 0) {
                String selectSql = "SELECT c_userid AS userId, c_username AS username, c_created_date AS createdDate " +
                                  "FROM r_user WHERE c_userid = ?";
                Map<String, Object> updatedUser = jdbcTemplate.queryForMap(selectSql, userId);
                
                response.put("success", true);
                response.put("message", "User updated successfully");
                response.put("user", updatedUser);
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Error updating user");
                return ResponseEntity.status(500).body(response);
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error updating user: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    public static class UpdateUserRequest {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}