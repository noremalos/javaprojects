package com.example.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class GetUsers {

    @Autowired
    private JdbcTemplate jdbcTemplate;


    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        try {
            String sql = "SELECT c_userid AS userId, c_username AS username, c_created_date AS createdDate " +
                         "FROM r_user";
            List<Map<String, Object>> users = jdbcTemplate.queryForList(sql);
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error obtaining user: " + e.getMessage());
            return ResponseEntity.status(500).body(List.of(response));
        }
    }
}
