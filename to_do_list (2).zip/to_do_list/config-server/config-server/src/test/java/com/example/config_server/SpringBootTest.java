package com.example.config_server;

public @interface SpringBootTest {

}
