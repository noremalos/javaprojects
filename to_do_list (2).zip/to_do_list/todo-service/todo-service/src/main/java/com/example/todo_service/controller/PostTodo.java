package com.example.todo_service.controller;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/todos")
public class PostTodo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping
    public ResponseEntity<Map<String, Object>> createTodo(@RequestBody CreateTodoRequest request) {
        Map<String, Object> response = new HashMap<>();

        try {
            
            if (request.getC_userid() == null) {
                response.put("success", false);
                response.put("message", "Field c_userid is required");
                return ResponseEntity.badRequest().body(response);
            }

            if (request.getC_username() == null || request.getC_username().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Field c_username is required");
                return ResponseEntity.badRequest().body(response);
            }

            if (request.getC_password() == null || request.getC_password().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Field c_password is required");
                return ResponseEntity.badRequest().body(response);
            }

            if (request.getC_title() == null || request.getC_title().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Field c_title is required");
                return ResponseEntity.badRequest().body(response);
            }

            if (request.getC_status() == null || request.getC_status().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Field c_status is required");
                return ResponseEntity.badRequest().body(response);
            }

            
            String checkUserSql = "SELECT COUNT(*) FROM r_user WHERE c_userid = ? AND c_username = ? AND c_password = ?";
            Integer userCount = jdbcTemplate.queryForObject(checkUserSql, Integer.class,
                    request.getC_userid(), request.getC_username(), request.getC_password());

            if (userCount == null || userCount == 0) {
                response.put("success", false);
                response.put("message", "Invalid credentials or user not found");
                return ResponseEntity.status(401).body(response);
            }

            // Insert new todo
            String insertSql = "INSERT INTO r_todo (c_userid, c_title, c_description, c_status, c_due_date, c_created_date) " +
                    "VALUES (?, ?, ?, ?, ?, NOW())";

            java.sql.Date dueDate = (request.getC_duedate() != null)
                    ? java.sql.Date.valueOf(request.getC_duedate())
                    : null;

            int rowsAffected = jdbcTemplate.update(insertSql,
                    request.getC_userid(),
                    request.getC_title(),
                    request.getC_description(),
                    request.getC_status(),
                    dueDate
            );

            if (rowsAffected > 0) {
                String selectSql = "SELECT c_todoid AS todoId, c_userid AS userId, c_title AS title, " +
                        "c_description AS description, c_status AS status, c_due_date AS dueDate, " +
                        "c_created_date AS createdDate, c_completed_date AS completedDate " +
                        "FROM r_todo WHERE c_userid = ? AND c_title = ? AND c_created_date = " +
                        "(SELECT MAX(c_created_date) FROM r_todo WHERE c_userid = ? AND c_title = ?)";

                Map<String, Object> newTodo = jdbcTemplate.queryForMap(selectSql,
                        request.getC_userid(), request.getC_title(),
                        request.getC_userid(), request.getC_title());

                response.put("success", true);
                response.put("message", "Todo created successfully");
                response.put("todo", newTodo);
                return ResponseEntity.status(201).body(response);
            } else {
                response.put("success", false);
                response.put("message", "Error creating todo");
                return ResponseEntity.status(500).body(response);
            }

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error creating todo: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    
    public static class CreateTodoRequest {
        private Long c_userid;
        private String c_username;
        private String c_password;
        private String c_title;
        private String c_description;
        private String c_status;

        @JsonFormat(pattern = "yyyy-MM-dd")
        private LocalDate c_duedate;

        public Long getC_userid() {
            return c_userid;
        }

        public void setC_userid(Long c_userid) {
            this.c_userid = c_userid;
        }

        public String getC_username() {
            return c_username;
        }

        public void setC_username(String c_username) {
            this.c_username = c_username;
        }

        public String getC_password() {
            return c_password;
        }

        public void setC_password(String c_password) {
            this.c_password = c_password;
        }

        public String getC_title() {
            return c_title;
        }

        public void setC_title(String c_title) {
            this.c_title = c_title;
        }

        public String getC_description() {
            return c_description;
        }

        public void setC_description(String c_description) {
            this.c_description = c_description;
        }

        public String getC_status() {
            return c_status;
        }

        public void setC_status(String c_status) {
            this.c_status = c_status;
        }

        public LocalDate getC_duedate() {
            return c_duedate;
        }

        public void setC_duedate(LocalDate c_duedate) {
            this.c_duedate = c_duedate;
        }
    }
}