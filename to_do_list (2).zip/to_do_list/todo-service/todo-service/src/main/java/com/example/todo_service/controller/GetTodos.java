package com.example.todo_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/todos")
public class GetTodos {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping("/")
    public ResponseEntity<Map<String, Object>> getTodos(@RequestBody ViewTodosRequest request) {
        Map<String, Object> response = new HashMap<>();

        try {
    
            if (request.getC_userid() == null ||
                request.getC_username() == null || request.getC_username().trim().isEmpty() ||
                request.getC_password() == null || request.getC_password().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Missing required fields");
                return ResponseEntity.badRequest().body(response);
            }

          
            String checkUserSql = "SELECT COUNT(*) FROM r_user WHERE c_userid = ? AND c_username = ? AND c_password = ?";
            Integer userCount = jdbcTemplate.queryForObject(checkUserSql, Integer.class,
                    request.getC_userid(), request.getC_username(), request.getC_password());

            if (userCount == null || userCount == 0) {
                response.put("success", false);
                response.put("message", "Invalid credentials");
                return ResponseEntity.status(401).body(response);
            }

        
            String selectSql = "SELECT c_todoid AS todoId, c_title AS title, c_description AS description, " +
                    "c_status AS status, c_due_date AS dueDate, c_created_date AS createdDate, " +
                    "c_completed_date AS completedDate FROM r_todo WHERE c_userid = ?";

            List<Map<String, Object>> todos = jdbcTemplate.queryForList(selectSql, request.getC_userid());

            response.put("success", true);
            response.put("message", "Todos retrieved successfully");
            response.put("todos", todos);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error retrieving todos: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    public static class ViewTodosRequest {
        private Long c_userid;
        private String c_username;
        private String c_password;

        public Long getC_userid() {
            return c_userid;
        }

        public void setC_userid(Long c_userid) {
            this.c_userid = c_userid;
        }

        public String getC_username() {
            return c_username;
        }

        public void setC_username(String c_username) {
            this.c_username = c_username;
        }

        public String getC_password() {
            return c_password;
        }

        public void setC_password(String c_password) {
            this.c_password = c_password;
        }
    }
}
