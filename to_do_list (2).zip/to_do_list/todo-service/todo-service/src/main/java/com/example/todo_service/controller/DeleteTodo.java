package com.example.todo_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/todos")
public class DeleteTodo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @DeleteMapping("/delete/{todoId}")
    public ResponseEntity<Map<String, Object>> deleteTodo(
            @PathVariable("todoId") Long todoId,
            @RequestBody DeleteTodoRequest request) {

        Map<String, Object> response = new HashMap<>();

        try {
            if (request.getC_userid() == null ||
                request.getC_username() == null || request.getC_username().trim().isEmpty() ||
                request.getC_password() == null || request.getC_password().trim().isEmpty()) {

                response.put("success", false);
                response.put("message", "Missing user credentials");
                return ResponseEntity.badRequest().body(response);
            }

            String checkUserSql = "SELECT COUNT(*) FROM r_user WHERE c_userid = ? AND c_username = ? AND c_password = ?";
            Integer userCount = jdbcTemplate.queryForObject(checkUserSql, Integer.class,
                    request.getC_userid(), request.getC_username(), request.getC_password());

            if (userCount == null || userCount == 0) {
                response.put("success", false);
                response.put("message", "Invalid user credentials");
                return ResponseEntity.status(401).body(response);
            }

            String deleteSql = "DELETE FROM r_todo WHERE c_todoid = ? AND c_userid = ?";
            int rowsAffected = jdbcTemplate.update(deleteSql, todoId, request.getC_userid());

            if (rowsAffected > 0) {
                response.put("success", true);
                response.put("message", "Todo deleted successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Todo not found or unauthorized");
                return ResponseEntity.status(404).body(response);
            }

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error deleting todo: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

  
    public static class DeleteTodoRequest {
        private Long c_userid;
        private String c_username;
        private String c_password;

        public Long getC_userid() {
            return c_userid;
        }

        public void setC_userid(Long c_userid) {
            this.c_userid = c_userid;
        }

        public String getC_username() {
            return c_username;
        }

        public void setC_username(String c_username) {
            this.c_username = c_username;
        }

        public String getC_password() {
            return c_password;
        }

        public void setC_password(String c_password) {
            this.c_password = c_password;
        }
    }
}
