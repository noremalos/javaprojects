package com.example.todo_service.controller;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/todos")
public class UpdateTodo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PatchMapping("/completed-date")
    public ResponseEntity<Map<String, Object>> updateCompletedDate(@RequestBody UpdateCompletedDateRequest request) {
        Map<String, Object> response = new HashMap<>();

        try {
            if (request.getC_todoid() == null || request.getC_completed_date() == null) {
                response.put("success", false);
                response.put("message", "Both c_todoid and c_completed_date are required");
                return ResponseEntity.badRequest().body(response);
            }

            String updateSql = "UPDATE r_todo SET c_completed_date = ? WHERE c_todoid = ?";
            int rowsAffected = jdbcTemplate.update(updateSql,
                    Date.valueOf(request.getC_completed_date()),
                    request.getC_todoid());

            if (rowsAffected > 0) {
                response.put("success", true);
                response.put("message", "Completed date updated successfully");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Todo not found or update failed");
                return ResponseEntity.status(404).body(response);
            }

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error updating completed date: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    public static class UpdateCompletedDateRequest {
        private Long c_todoid;

        @JsonFormat(pattern = "yyyy-MM-dd")
        private LocalDate c_completed_date;

        public Long getC_todoid() {
            return c_todoid;
        }

        public void setC_todoid(Long c_todoid) {
            this.c_todoid = c_todoid;
        }

        public LocalDate getC_completed_date() {
            return c_completed_date;
        }

        public void setC_completed_date(LocalDate c_completed_date) {
            this.c_completed_date = c_completed_date;
        }
    }
}
