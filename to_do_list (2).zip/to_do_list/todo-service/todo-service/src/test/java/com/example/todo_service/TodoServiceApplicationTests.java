package com.example.todo_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
